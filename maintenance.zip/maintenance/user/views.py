from django.utils import timezone
from rest_framework.viewsets import ModelViewSet
from rest_framework.decorators import action, api_view,permission_classes
from rest_framework.authtoken.models import Token
from rest_framework.authtoken.views import ObtainAuthToken
from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework.permissions import IsAuthenticated
from rest_framework import status
from drf_spectacular.utils import extend_schema, extend_schema_view
from .models import Utilisateur, EntiteMetier
from security.models import Role, UserRole
from security.permission import HasPermissionFactory
from .serializers import  SetPasswordSerializer, UtilisateurSerializer,  EntiteMetierSerializer, UtilisateurUpdateSerializer
from .serializers import LoginSerializer
from django.contrib.auth import authenticate
from utils import LDAP_connect 
import uuid 
from rest_framework_simplejwt.tokens import RefreshToken


@api_view(['POST'])
@permission_classes([IsAuthenticated, HasPermissionFactory('MANAGE_USERS')])
def create_user(request):
    
    try:
        try: 
            role = Role.objects.get(code_role = request.data['code_role'])
        except Role.DoesNotExist: 
            return Response({'Error':'Role non existant'}, status=status.HTTP_400_BAD_REQUEST)
        
        user = Utilisateur.objects.create_user(
            username = request.data['username'],
            first_name = request.data['first_name'],
            last_name = request.data['last_name'],
            email = request.data['email'],
            password = request.data['password'],
            first_connection = True,
            is_ldap = request.data['is_ldap']
        )
        UserRole.objects.create(
            user = user,
            role = role
        )
        
        return Response({"message" :"User ok"}, status=status.HTTP_201_CREATED)
    
    except Exception as e: 
        return Response({'Error':str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

# list all user

@api_view(['GET'])
@permission_classes([IsAuthenticated,HasPermissionFactory('MANAGE_USERS')])
def get_users(request):
    # if not request.user.is_authenticated:
    #     return Response(
    #         {'error': 'Authentification requise'}, 
    #         status=status.HTTP_401_UNAUTHORIZED)

    users = Utilisateur.objects.filter(is_deleted = False)
    serializer = UtilisateurSerializer(users, many = True)
    if serializer.is_valid:
        return Response(serializer.data) 

# find user

@api_view(['GET'])
@permission_classes([IsAuthenticated])
def find_user(request, user_id):
    try :
        user = Utilisateur.objects.get(id=user_id)
    except Utilisateur.DoesNotExist:
        return Response({'error': 'User does not exist'}, status=status.HTTP_404_NOT_FOUND)
    
    serialzer =UtilisateurSerializer(user, many=False)
    return Response(serialzer.data, status=status.HTTP_200_OK)

# update user

@api_view(['PUT', 'PATCH'])
@permission_classes([IsAuthenticated,HasPermissionFactory('MANAGE_USERS')])
def get_update_user(request, user_id):
    try:
        
        user = Utilisateur.objects.get(id =user_id)
    except Utilisateur.DoesNotExist:
        return Response({'error': 'User not found'}, status=status.HTTP_404_NOT_FOUND)
    
    if request.method == 'PUT':
        serializer = UtilisateurUpdateSerializer(user, data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_200_OK)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
    
    if request.method == 'PATCH':
    
        serializer = UtilisateurUpdateSerializer(user, data=request.data, partial=True)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_200_OK)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
    
    #Update role si fourni
    if request.data.get('code_role'):
       role = Role.objects.get(code_rol=request.data.get('code_role'))
       user_role = UserRole.objects.filter(user=user).first()

       if user_role:
          user_role.role = role
          user_role.save()
       else:
           UserRole.objects.create(user=user, role=role)

    return Response({"message": "User updated"}, status=status.HTTP_200_OK)

    
# delete user
@api_view(['DELETE'])   
@permission_classes([IsAuthenticated,HasPermissionFactory('MANAGE_USERS')]) 
def delete_user(request, user_id):
    try:    
        user = Utilisateur.objects.get(id=user_id)
        user.is_deleted = True
        user.is_active = False
        user.deleted_at = timezone.now()
        user.save()
        return Response({"message": "User deleted"}, status=status.HTTP_204_NO_CONTENT)

    except Utilisateur.DoesNotExist:
        return Response({'error': 'User not found'}, status=status.HTTP_404_NOT_FOUND)
    
    
    
#restauration d'un utilisateur
@api_view(['PATCH'])
@permission_classes([IsAuthenticated,HasPermissionFactory('MANAGE_USERS')])
def restore_user(request, user_id):
    try:
        user = Utilisateur.objects.get(id=user_id)
          
        if not user.is_deleted:
            return Response({'error': 'Cet utilisateur n\'est pas supprimé'},status=status.HTTP_400_BAD_REQUEST) 

        user.is_deleted = False
        user.deleted_at = None
        user.save()

        return Response({'message': 'Utilisateur restauré avec succès'},status=status.HTTP_200_OK)

    except Utilisateur.DoesNotExist:
        return Response({'error': 'Utilisateur non trouvé'},status=status.HTTP_404_NOT_FOUND)


# changer de password

@api_view(['POST'])
@permission_classes([IsAuthenticated])

def change_password(request):
    user = request.user   
    new_password = request.data.get('new_password') 
    
    if not new_password:
        return Response({"error": "mot de passe requis"},status=status.HTTP_400_BAD_REQUEST)
    
    #controle sur la longueur du password
    if len(new_password) < 8:
        return Response({"error": "mot de passe trop court.Au moins 8 caractères"}, status=status.HTTP_400_BAD_REQUEST)
    
    user.set_password(new_password)
    
    if hasattr(user, "first_connection"):
        user.first_connection = False
        
    user.save()
    
    return Response({"message": "Mot de passe mis à jour avec succès"}, status=status.HTTP_200_OK)



    #login api
class LoginAPIView(APIView):
    """
    API endpoint pour l'authentification des utilisateurs
    Supporte l'authentification locale et LDAP
    """
    permission_classes = []  # Pas d'authentification requise pour le login
    authentication_classes = []  # Pas d'authentification requise pour le login
    
    def post(self, request) :
        username = request.data["username"]
        password = request.data["password"]
        try: 
            user = Utilisateur.objects.get(username=username)
            
        except Utilisateur.DoesNotExist:
            
            return Response({"error":"user does not exist"}, status=status.HTTP_400_BAD_REQUEST)
        
        if user.is_active == False:
            
            return Response({"error":"account blocked"}, status=status.HTTP_400_BAD_REQUEST)
          
        if user.is_deleted == True:
            
            return Response({"error":"user does not exist"}, status=status.HTTP_400_BAD_REQUEST)
           
        if user.is_ldap :
            try:
                
                LDAP_connect.ldap_login(username, password)
                # logger.info("LDAP Auth OK pour %s", username)
            except Exception as e:
                # logger.warning("Échec LDAP pour %s : %s", username, str(e))
                return Response({"error":"Invalid username and password"}, status=status.HTTP_400_BAD_REQUEST)
                
        else:
            auth = authenticate(username=username , password=password)
            
            if auth is None :
                return Response({"error":"Invalid username and password"}, status=status.HTTP_400_BAD_REQUEST)
                 
        refresh = RefreshToken.for_user(user)
        

        return Response ({
            "user_id" : str(user.id),
            "access" :  str(refresh.access_token),
            "refresh" :  str(refresh)
        })
    
class LogoutAPIView(APIView):
    """Déconnexion de l'utilisateur"""
    
    def post(self, request):
        # Vider la session
        request.session.flush()
        return Response({'success': True,'message': 'Déconnexion réussie'}, status=status.HTTP_200_OK)


        
class EntiteMetierViewSet(ModelViewSet):
    queryset = EntiteMetier.objects.all()
    serializer_class = EntiteMetierSerializer